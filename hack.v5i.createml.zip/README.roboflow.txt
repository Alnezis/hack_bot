
hack - v5 2022-05-14 1:20pm
==============================

This dataset was exported via roboflow.ai on May 15, 2022 at 11:27 AM GMT

It includes 34 images.
Letters are annotated in CreateML format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Fit within)

The following augmentation was applied to create 3 versions of each source image:
* Random brigthness adjustment of between -34 and +34 percent


